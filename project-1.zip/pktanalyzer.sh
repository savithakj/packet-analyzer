#!/bin/bash
# shell command for packet analyser
python -u packet.py $1